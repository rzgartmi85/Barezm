# Ya Hakeem · Medical Education

This repository holds the Ya Hakeem web app (`index.html`), its Android app build, and the question bank PDFs.

* **Android APK**: built automatically by GitHub Actions (`.github/workflows/build-apk.yml`) with Capacitor.
* **PDFs**: stored in `pdf/` and attached to a release called **latest**, so people can download them directly.
* **Download links**: the side menu ("Download Android app", "Download PDF" under each specialty) and the question bank pages already point at the release. The workflow fills in your GitHub username and repository name for you (`__GH_OWNER__` and `__GH_REPO__` in `index.html`). You do not need to edit anything.

## Quickest setup (no unzipping)

1. Upload `ya-hakeem-github-repo.zip` to the repository root as it is (Add file → Upload files). Replace the old zip if there is one.
2. Make sure `.github/workflows/build-apk.yml` contains the workflow from this project.
3. Settings → Actions → General → Workflow permissions → **Read and write**.
4. Open the Actions tab and wait for the run (or Run workflow). When it finishes it saves `YaHakeem.apk` and both PDFs in the repository root. The app's download links point to those files:
   * `https://github.com/rzgartmi85/Barezm/raw/main/YaHakeem.apk`
   * `https://github.com/rzgartmi85/Barezm/raw/main/Dermatology_Venereology_Question_Bank_QA.pdf`
   * `https://github.com/rzgartmi85/Barezm/raw/main/Rheumatology_Question_Bank_QA.pdf`

The workflow also attaches the same files to a release called "latest".

## One-time setup (unzipped layout) (all in the GitHub website, no unzipping or git needed)

1. Create a **public** repository on GitHub (private repositories hide release downloads from visitors).
2. Click **Add file → Upload files** and drag in these files, all at the top level of the repository:
   `index.html`, `package.json`, `capacitor.config.json`, `icon-only.png`, `icon-foreground.png`, `icon-background.png`, `README.md` and the two `.pdf` files. Commit.
3. Click **Add file → Create new file**. In the name box type `.github/workflows/build-apk.yml` (typing the slashes creates the folders), paste in the contents of `build-apk.yml`, and commit.
4. Go to **Settings → Actions → General → Workflow permissions** and choose **Read and write permissions**.
5. Open the **Actions** tab. The workflow starts after the commit in step 3 (or choose *Build Android APK and publish downloads → Run workflow*). It takes about 5 to 10 minutes.
6. When it finishes, open **Releases → Ya Hakeem - latest downloads**. You will find `YaHakeem.apk` and both PDFs there, and the download links in the app now work.

The workflow moves the icons into `assets/` and the PDFs into `pdf/` on its own while building, so the flat layout is fine.

## Updating

* **New PDFs:** upload new files with the same names (Add file → Upload files, then commit). The workflow re-attaches them to the release.
* **App changes:** upload or edit `index.html` and commit, and a new APK is built. Keep the `__GH_OWNER__` and `__GH_REPO__` placeholders as they are.

## Signing the APK (recommended)

Without a signing key the workflow builds a *debug* APK. It installs fine, but every build is signed with a different temporary key, so Android will refuse to update an installed copy (the old one must be uninstalled first). To avoid that, sign every build with your own key:

1. Create a key once, on your computer, and keep the file safe:

   ```
   keytool -genkeypair -v -keystore yahakeem.keystore -alias yahakeem -keyalg RSA -keysize 2048 -validity 10000
   base64 -w0 yahakeem.keystore      # on macOS: base64 -i yahakeem.keystore
   ```
2. In **Settings → Secrets and variables → Actions** add these repository secrets:
   * `KEYSTORE_BASE64`: the output of the base64 command
   * `KEYSTORE_PASSWORD`: the keystore password you chose
   * `KEY_ALIAS`: `yahakeem` (or the alias you chose)
   * `KEY_PASSWORD`: only if the key password differs from the keystore password

   Never upload the keystore file itself to the repository.

The next run produces a signed release APK automatically.

## Notes

* The app is the same web app wrapped in a native Android shell. It needs an internet connection for images, videos and the download links. Progress is stored on the phone.
* In the Android app the "Download Android app" menu item is hidden, and PDF links open in the phone's browser.
* If you host `index.html` on GitHub Pages (`https://USER.github.io/REPO/`), the download links work there too.
* Each PDF is under 10 MB, well inside GitHub's file limits, so no Git LFS is needed.
